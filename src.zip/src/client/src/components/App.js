import React from 'react';
// Bootstrap components
import Container from 'react-bootstrap/Container';
// Pages
import Home from '../pages/Home';


function App() {
	return (
		
		<Home />
	);
}

export default App;
